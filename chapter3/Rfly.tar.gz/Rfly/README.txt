Install Raspberry Fly with:

  python setup.py install

Or

  python setup.py install --prefix=/some/where/else

