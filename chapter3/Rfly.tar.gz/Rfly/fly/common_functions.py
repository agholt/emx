#!/usr/bin/env python

import sys
import os
import time
import exceptions
import traceback

from constants import *


class BackSignal(exceptions.Exception):
    def __init__(self, args=None):
        self.args=args
        self.errmsg = ''
        for a in self.args:
            self.errmsg += str(a)



base_config = """DEBUG=0
FLY_STATE=0
LR_DELAY=1.0
UD_DELAY=1.2
"""

# Find configuration file and use to set environment
# variables
def set_env(config="my.conf"):

    global env
    lines = []

    pname = sys.argv[0]
    myhome = os.environ['HOME']

    fly_dir = "%s/%s" % (myhome,".fly")
    config_file = "%s/%s" % (fly_dir, config)


    # create  directory if it does not exist
    if not os.path.exists(fly_dir):
        print "%s does not exist, attepting to create it... " % (fly_dir)
        try:
            os.makedirs(fly_dir)
        except OSError, e:
            print "Error creating %s, %s" % (fly_dir, e.args)
            os._exit(-1)
        except:
            print "error creating %s directory" % (fly_dir)
            os._exit(-1)
        print "%s has been created" % (fly_dir)

    # if it does exist, then check it
    # is actually a directory
    if not os.path.isdir(fly_dir):
        print "%s is not a directory" % (fly_dir)
        os._exit(-2)

    # If the config does not exist, create it
    # with a base config
    if not os.path.exists(config_file):
       try:
           fd = open(config_file, 'w')
           fd.write(base_config)
           fd.close()
       except:
            print "error creating %s file" % (config_file)

    try:
        lines = open(config_file,'r').readlines()
    except:
        print "could not open %s" % (config_file)
        # os._exit(-2)


    for line in lines:
        # Remove trailling comments
        try:
            expression, comment = line.split('#')
        except ValueError, e:
            expression = line

        # Get name/value pair
        try:
            name, value = expression.split('=')
        except ValueError, e:
            pass

        # Remove leading/trailling white space and newline
        env[name.strip()]=value.strip().strip('\n')

    return 0





if __name__=='__main__':

    set_env()
    print env





def set_env2(config="my.conf"):

    global env
    try:
        lines = open(config,'r').readlines()
    except:
        print "could not open file %s" % (config)
        sys.exit(-1)

    for line in lines:
        try:
            name, value = line.split('=')
        except ValueError, e:
            pass
        env[name]=value.strip('\n')

    return 0


def restore_terminal(stdscr):
      stdscr.keypad(0)
      curses.echo()
      curses.nocbreak()
      curses.endwin()
      traceback.print_exc()
      return 1


def set_log_directory():

    global env
    if env.has_key('LOGFILE'):
	logfile = env['LOGFILE']
	logdir = os.path.dirname(logfile)
    else:
	logdir = "%s/%s" % (os.environ['HOME'],".rfly")
	logfile = "%s/%s" % (logdir,"fly.log")
	env['LOGFILE'] = logfile


    # create log directory if it does not exist
    if not os.path.exists(logdir):
	 print "%s does not exist, attepting to create it... " % (logdir)
	 try:
	     os.makedirs(logdir)
	 except OSError, e:
	     print "Error creating %s, %s" % (logdir, e.args)
	     os._exit(-1)
	 except:
	     print "error creating %s directory" % (pcapd)
	     os._exit(-1)
	 print "%s has been created" % (logdir)

    # if it does exist, then check it
    # is actually a directory
    if not os.path.isdir(logdir):
	print "%s is not a directory" % (logdir)
	os._exit(-2)


    # Check we have permissions to create a file
    # in this directory.
    try:
	fd = open(logfile,'w')
    except IOError, e:
	# we don't, so don't continue
	if e.args[1] == "Permission denied":
	    print "You do not have permission to create files in this directory."
	    os._exit(-3)

    fd.close()

    return 0



def get_time():

    w,m,d,t,y = time.ctime(time.time()).split()
    return(t)


def int2bin(n, count=24):
    return "".join([str((n >> y) & 1) for y in range(count-1, -1, -1)])



def quit_func(stdscr):
    restore_terminal(stdscr)
    os._exit(0)



