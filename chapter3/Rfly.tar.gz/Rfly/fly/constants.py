#!/usr/bin/env python

import curses

__program__   = "rfly.py"
__author__    = "Alan Holt"
__version__   = "v0.2"
__revision__  = "$Rev: 1 $"
__date__      = "$Date: 2012-05-01 09:00:00 (Mi, 1st May 2012) $"
__copyright__ = "Alan Holt"


version = __version__

env = { 'DEBUG' : 0 }


# Files 

logfile = "logfile"
banner_file2 = "banner.txt"

# Text effects:

hotkey_attr = curses.A_BOLD | curses.A_UNDERLINE # Bold
bold_attr = curses.A_BOLD
uline_attr = curses.A_UNDERLINE
bold_uline_attr = curses.A_BOLD | curses.A_UNDERLINE # Underline and bold
blink_attr = curses.A_BLINK
bold_blink_attr = curses.A_BLINK | curses.A_BOLD
norm_attr = curses.A_NORMAL
menu_attr = curses.A_NORMAL
standout_attr = curses.A_STANDOUT

borders = (1,77,1,13)
#WDIMS = (13,79,3,0)
WDIMS = (15,79,3,0)
NROWS = 13 # No. rows
NCOLS = 77 # No. columns

START_CHANCE = 10
CHANCE = 50
START_X = 40
START_Y = 7

UP,DOWN,LEFT,RIGHT = (0,1,2,3)
sprite_list = ("^", "V", "<",">")



non_zero_ints = ["1","2","3","4","5","6","7","8","9"]
times_ten_ints = ["A","B","C","D","E","F","G","H","I"]
BLOCK = "X"

# Probability distributions
dist1 = [1,1,2,2,2,2,3,3,3,3,3,4,4,5,6,7]
dist2 = [1,1,2,2,2,2,2,2,3,3,3,4,5]
dist3 = [1,1,1,2,2,2,2,2,2,3,3,3,3,4,5,6]
dist4 = [1,2,2,2,2,2,3,3,3,3,4,4,4,4,4,5,5,6]


# States
NORM_FLY        = int(0)
SUPER_FLY       = int(1)
SUPER_PLUS_FLY  = int(2)
SUPER_PLUS2_FLY = int(3)
MEGA_FLY        = int(4)

SUPER_FLY_SCORE = 21
CLEAR_BLOCK_SCORE = 4000
CLEAR_BLOCK_SCORE2 = 8000
MEGA_FLY_SCORE = 1000 
LETTER_SCORE = 20
SUPER_PLUS_BONUS  = int(250)

fly_lst = ["f","l","y"]

tty = ""
isSerial = 0




banner_text = """  _______                       __
 |   _   \.---.-..-----..-----.|  |--..-----..----..----..--.--.
 |.  l   /|  _  ||__ --||  _  ||  _  ||  -__||   _||   _||  |  |
 |.  _   1|___._||_____||   __||_____||_____||__|  |__|  |___  |
 |:  |   |              |__|                             |_____|
 |::.|:. |
 `--- ---'     _______  __
              |   _   ||  |.--.--.
              |.  1___||  ||  |  |
              |.  __)  |__||___  |
              |:  |        |_____|
              |::.|
              `---'
"""
