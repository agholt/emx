#!/usr/bin/env python
 
import sys
import string, os
import re, operator
import time, signal
import termios
import traceback
import curses
import select

from optparse import OptionParser

from constants import *
from common_functions import *
from main_menu import *
from service_screens import *


# Define options
def proc_options():
    parser = OptionParser()
    parser.add_option('-v', '--version', 
                      action="store_true",
                      dest="version_flag",
                      default=False,
                      help = 'show version')

    return parser.parse_args(sys.argv[1:])



def menu(stdscr):

    global env
    servscr = ServScreens(stdscr)
    mainscr = Mainmenu(stdscr,servscr)


def start():

    set_env()
    #set_log_directory()

    options,files = proc_options()
    if options.version_flag:
        print "Version: %s" % (version)
        exit(0)


    try:
        stdscr=curses.initscr()
    except:
        # In event of error, restore terminal to sane state.
        curses.echo() 
        restore_terminal(stdscr)

    height,width = stdscr.getmaxyx()
    if (height < 24 or width < 80):
        curses.echo() 
        restore_terminal(stdscr)
        print "Terminal window too small, it needs to be 24x80"
        exit(0)

    try:
        curses.noecho()
        curses.cbreak()
        stdscr.keypad(1)
        menu(stdscr)   # Enter the main loop

    except:
        # In event of error, restore terminal to sane state.
        curses.echo() 
        restore_terminal(stdscr)


if __name__=='__main__':

    start()


