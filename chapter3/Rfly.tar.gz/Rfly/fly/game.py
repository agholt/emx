#!/usr/bin/env python
 
import sys,os,re
import string
import shutil
import time
import traceback
import exceptions
import curses
import commands
import random

from constants import *
from common_functions import *
from windows import *
from options import *
 


class Pitch(Options,Windows):
    def __init__(self,screen,logscr):

        self.screen = screen
        self.logscr = logscr

        self._set_params()

    def prize_draw(self):
        self.gen_prizes()
        self.proc_pitch()
        self.display_prizes()


    # Generate prizes
    def gen_prizes(self):
        
        self.prize_list = []

        # Take a sample (of 1) from dist
        N = random.sample(self.dist,1)[0]

        for n in range(N):
            y = random.randint(0,self.nrows-1)
            x = random.randint(0,self.ncols-1)
            val = self.pitch[y][x]

            # Check this is not a BLOCK or "F", "L" or "Y"
            #if (val != BLOCK or val not in fly_lst):
            if (val == "0"):
                dmesg = "block is: %s" % (val)
                #self.debug_output(dmsg, 3)
                self.debug_output(dmesg, 1)
                v = random.randint(1,9)
                p = (y,x,str(v))
                self.prize_list.append(p)

        # If in Super Fly state then generate x10 prizes
        if (self.fly_state >= SUPER_FLY):
            # Take a sample (of 1) from super_dist
            N = random.sample(self.super_dist,1)[0]

            for n in range(N):
                y = random.randint(0,self.nrows-1)
                x = random.randint(0,self.ncols-1)
                val = self.pitch[y][x]

                # Check this is not a BLOCK or "F", "L" or "Y"
                #if (val != BLOCK or val not in fly_lst):
                if (val == "0"):
                    #debug_output("block is: %s" % (val), 3)
                    v = random.randint(1,9)
                    u = times_ten_ints[v-1]
                    p = (y,x,str(u))
                    self.prize_list.append(p)

        # If in Super Plus Fly state add
        # letters "F","L" and "Y"
        if (self.fly_state == SUPER_PLUS_FLY):
            for letter in fly_lst:
                while 1:
                    y = random.randint(0,self.nrows-1)
                    x = random.randint(0,self.ncols-1)
                    # Check this is not a BLOCK
                    if (self.pitch[y][x] != BLOCK):
                        break

                p = (y,x,letter)
                self.prize_list.append(p)
                self.change_state(SUPER_PLUS2_FLY)

    # Place prizes on the pitch 
    def proc_pitch(self):
        for p in self.prize_list:
            y,x,val = p 
            self.pitch[y][x] = val

    # Display prizes on the screen 
    def display_prizes(self):

        for i in range(self.nrows):
            for j in range(self.ncols):
                v = self.pitch[i][j]
                y,x = (i+1,j+1)
                # Units
                if (v in non_zero_ints):
                     self.screen.addstr(y, x, v, norm_attr)
                # Tens
                if (v in times_ten_ints):
                     u = str(int(times_ten_ints.index(v)) + 1)
                     self.screen.addstr(y, x, u, standout_attr)
                # F.L.Y letters
                if (v in fly_lst):
                     u = v.upper() # convert to upper case
                     self.screen.addstr(y, x, u, norm_attr)

    # Reset a point
    def reset_point(self,y,x):
        self.pitch[y][x] = "0"

    # This method isn't used
    def clear_prizes(self,n):
        ys = [random.randint(0,self.nrows-1) for i in range(n)]
        xs = [random.randint(0,self.ncols-1) for i in range(n)]
        for i in range(n):
            y = ys[i]
            x = xs[i]
            if (self.pitch[y][x] == BLOCK):
                continue
            if (self.pitch[y][x] == ">"):
                continue
            self.reset_point(y,x)
   
    # Clear all the obstacle blocks 
    def clear_blocks(self):
        nblocks = 0
        for y in range(self.nrows):
            for x in range(self.ncols):
                if (self.pitch[y][x] == BLOCK):
                    self.reset_point(y,x)
                    self.screen.addstr(y+1, x+1, " ", norm_attr)
                    nblocks += 1
        self.screen.refresh()
        return nblocks


    # Change the state
    def change_state(self, state):
        self.fly_state = state

    # Get the state
    def get_state(self):
        return self.fly_state


    # Set any environment variables and parameters
    def _set_params(self):

        # Debug level
        if env.has_key('DEBUG'):
            self.DEBUG = int(env['DEBUG'])
        else:
            self.DEBUG = 0

        # Initialise fly state
        if env.has_key('FLY_STATE'):
            self.fly_state = int(env['FLY_STATE'])
        else:
            self.fly_state = NORM_FLY

        self.nrows = NROWS
        self.ncols = NCOLS

        # initialise pitch
        self.pitch = []
        for n in range(self.nrows):
            self.pitch.append(list("0" * self.ncols))

        # Probability distributions
        self.dist = dist1
        self.super_dist = dist3
                    


                                                                                
class Fly(Options,Windows):

    def __init__(self,screen,logscr,borders, P):

        self.screen = screen
        self.logscr = logscr
        self._set_params()

        self.logscr.write_to_title("score: ", 65, standout_attr)

        self.score = 0
        score_text = str(self.score).zfill(6)
        self.display_score()

        self.fly_word = ""

        # Make the pitch object accessible for 
        # for all methods
        self.P = P

        self.draw_fly(">")

    def draw_fly(self,sprite):
        self.screen.addstr(self.y, self.x, sprite, norm_attr) 
        self.screen.refresh()

    # Return the position of the Fly (screen coords)
    def get_pos(self):
        return(self.x, self.y)


    def render(self,direction):

        # Convert screen coords to pitch matrix coords
        iy,ix = (self.y - 1, self.x - 1)

        # Decide whether to give some prizes
        if(random.randint(1,self.chance) == 1):
            self.P.prize_draw()
            # Lower chance of generating prizes
            self.chance = CHANCE


        # Determine "sprite" based upon direction of travel
        sprite = sprite_list[self.direction]

        # Display sprite
        self.draw_fly(sprite)

        if (self.trail > 0):
            self.screen.addstr(self.last_y, self.last_x, " ", standout_attr)
            #self.screen.addstr(self.last_y, self.last_x, str(self.trail), standout_attr)

            self.trail -= 1 # Decrement trail
            last_iy = self.last_y - 1
            last_ix = self.last_x - 1
            self.P.pitch[last_iy][last_ix] = BLOCK
        else:        
            self.screen.addstr(self.last_y, self.last_x, " ", norm_attr)

        self.screen.refresh()



        # Has the fly gone out of bounds, if so, Game Over!
        if (self.x >= self.r_border or self.x <= self.l_border or self.y < self.t_border or self.y >= self.b_border):
            dmesg="Out of bounds"
            self.debug_output(dmesg, 1)
            return -1

        val = self.P.pitch[iy][ix] 

        # Has the fly hit something, if so, Game Over!
        if (val == BLOCK):
            dmesg="You hit something"
            self.debug_output(dmesg, 1)
            return -1


        # Check if got regular number
        if (val in non_zero_ints):
           
            nval = int(val)
            if (self.fly_state >= SUPER_FLY):
                self.trail = nval
            else:
                self.trail += nval

            # Calculate and display score
            self.score += nval
            self.display_score()

            # If score a multiple of 21: Super Fly 
            if ((self.score % SUPER_FLY_SCORE) == 0):
                if (self.fly_state < SUPER_FLY): 
                    self.fly_state = SUPER_FLY
                    self.P.change_state(self.fly_state)
                    self.dist = dist2 # Change probabilty distribution
                    dmesg="Super Fly!"
                    self.debug_output(dmesg, 2)
         

        # Check if got inverse video numbers
        if (val in times_ten_ints):
            nval = 10 * (int(times_ten_ints.index(val)) + 1)
            self.score += nval
            self.display_score()
            self.P.reset_point(iy,ix)

            # Debug output
            #dmesg="got: %s at %s,%s" % (val,iy,ix)
            #self.debug_output(dmesg, 4)
            #dmesg="trail: %s" % (self.trail)
            #self.debug_output(dmesg, 4)

        # Check if got "F", "L" or "Y"
        if (val in fly_lst):
            self.fly_word += val
            self.score += LETTER_SCORE
            dmesg="Got: %s" % (self.fly_word.upper())
            self.debug_output(dmesg, 3)
            self.P.reset_point(iy,ix)

            if (len(self.fly_word) == 3):

                # If "F", "L" and "Y" collected in any order
                # then give Super+ Fly bonus
                self.score += SUPER_PLUS_BONUS
                self.display_score()
                dmesg="Bonus: %d" % (SUPER_PLUS_BONUS)
                self.debug_output(dmesg, 1)

              
                # If "F", "L" and "Y" collected in order
                # then go Mega Fly
                if (self.fly_word == "".join(fly_lst)):
                    # Change state to Mega Fly
                    self.fly_state = MEGA_FLY
                    self.P.change_state(self.fly_state)

                    # Change probability distributions
                    self.dist = dist1
                    self.super_dist = dist4

                    # Clear the blocks and add no. blocks to score
                    nblocks = self.P.clear_blocks()
                    self.score += nblocks
                    self.display_score()

                    dmesg="Mega Fly! Destroyed %d blocks" % (nblocks)
                    self.debug_output(dmesg, 3)

        if (self.score > MEGA_FLY_SCORE):
            self.fly_state = self.P.get_state()

            # Change to Super+ Fly state if not in
            # Super+ Fly state already
            if (self.fly_state < SUPER_PLUS_FLY): 
                # Change state
                self.fly_state = SUPER_PLUS_FLY
                self.P.change_state(self.fly_state)

                dmesg="Super+ Fly!"
                self.debug_output(dmesg, 2)

        #if ((self.score % CLEAR_BLOCK_SCORE) == 0):
        if (self.score > CLEAR_BLOCK_SCORE and self.blocks_cleared == 0):
            nblocks = self.P.clear_blocks()
            self.blocks_cleared = 1
        if (self.score > CLEAR_BLOCK_SCORE2 and self.blocks_cleared == 0):
            nblocks = self.P.clear_blocks()
            self.blocks_cleared = 1

        return 0

    # Display score in top bar
    def display_score(self):
        score_text = str(self.score).zfill(6)
        self.logscr.write_to_title(score_text, 72, standout_attr)


    def move(self,direction):
  
        self.direction = direction
        self.last_x = self.x
        self.last_y = self.y

        if (self.direction == RIGHT):
            self.x +=1
            self.delay = self.lr_delay
            return 0
        if (self.direction == LEFT):
            self.x -=1
            self.delay = self.lr_delay
            return 0
        if (self.direction == UP):
            self.y -=1
            self.delay = self.ud_delay
            return 0
        if (self.direction == DOWN):
            self.y +=1
            self.delay = self.ud_delay
            return 0

    # Get the score
    def get_score(self):
        return self.score

    # Set environment variables and parameters
    def _set_params(self):

        # Debug level
        if env.has_key('DEBUG'):
            self.DEBUG = int(env['DEBUG'])
        else:
            self.DEBUG = 0

        self.l_border = 0
        self.r_border = 78
        self.t_border = 1
        self.b_border = 14

        self.chance = START_CHANCE
        self.trail = 0

        # Initialise fly state
        if env.has_key('FLY_STATE'):
            self.fly_state = int(env['FLY_STATE'])
        else:
            self.fly_state = NORM_FLY

        self.y = START_Y
        self.x = START_X
        self.last_y = self.y
        self.last_x = self.x

        # Initialise fly state
        if env.has_key('LR_DELAY'):
            self.lr_delay = float(env['LR_DELAY'])
        else:
            self.lr_delay = 0.1

        # Initialise fly state
        if env.has_key('UD_DELAY'):
            self.ud_delay = float(env['UD_DELAY'])
        else:
            self.ud_delay = 0.12

        self.blocks_cleared = 0







class GameOver(Options,Windows):
    def __init__(self, stdscr,logscr):
        self.stdscr = stdscr
        self.logscr = logscr

        self.stdscr.erase()
        wdims = (6,40,6,17)
        self._draw_screen("GAME OVER!", wdims, bold_attr)
        curses.flushinp()
        time.sleep(1)
        self._any_key()


class Game(Options,Windows):

    def __init__(self, stdscr,logscr):

        self.stdscr = stdscr
        self.logscr = logscr

        # Process any environment variables
        self._set_params()

        self._draw_area(self.wdims, bold_uline_attr)

        # Create the pitch and fly 
        self.P = Pitch(self.subscr,self.logscr)
        self.F = Fly(self.subscr,self.logscr,self.borders,self.P)

        self.subscr.refresh()

        self.subscr.keypad(1)
        curses.raw()
        curses.cbreak()
        curses.noecho() 
        curses.curs_set(0) 

        self.play()
        curses.flushinp()

        # If you've exited from "play()" then game over

        final_score = self.F.get_score()
        dmesg="Game over! You scored: %d" % (final_score)
        self.debug_output(dmesg, 1)

        E = GameOver(stdscr,logscr)
        self.logscr.title_window()


        self.subscr.erase()



    def play(self):
        last_key = -1
 
        direction = None

        while 1:
            self.subscr.refresh()
            self.subscr.timeout(-1)
            self.subscr.nodelay(1)
            c = self.subscr.getch()

            if(c == last_key):
                curses.flushinp()

            # Debug output
            #char = "key: %s" % (str(c))
            #self.debug_output(char, 2)

            if c ==  ord("q"): 
                curses.flushinp()
                break  # q
            elif c == curses.KEY_RIGHT: 
                direction = RIGHT
                self.delay = 0.1
            elif c == curses.KEY_LEFT: 
                self.delay = 0.1
                direction = LEFT
            elif c == curses.KEY_UP: 
                self.delay = 0.15
                direction = UP 
            elif c == curses.KEY_DOWN: 
                self.delay = 0.15
                direction = DOWN

            if (direction != None):
                self.F.move(direction)
                x,y = self.F.get_pos()

                # Debug output
                #dmesg="pos: %s,%s" % (str(x),str(y))
                #self.debug_output(dmesg, 3)

                if (self.F.render(direction) < 0):
                    self.subscr.refresh()
                    break

            last_key = c
            time.sleep(self.delay)


    def fly_update(self,direction):

        if direction == RIGHT:
            self.debug_output("Going right", 2)
        if direction == LEFT:
            self.debug_output("Going left", 2)
        if direction == UP:
            self.debug_output("Going up", 2)
        if direction == DOWN:
            self.debug_output("Going down", 2)
            

    #def fill_screen(self):


    #    self.down,self.left = 3,24
    #    self.subscr.refresh()



    # Set any environment variables
    def _set_params(self):

        # Debug level
        if env.has_key('DEBUG'):
            self.DEBUG = int(env['DEBUG'])
        else:
            self.DEBUG = 0

        self.wdims = WDIMS
        #self.wdims = (15,79,3,0)
        self.delay = 0.1

        #self.left_border = 1
        #self.right_border = 77
        #self.top_border = 1
        #self.bottom_border = 13

        #self.borders = (self.right_border, self.left_border, self.top_border, self.bottom_border)

        #self.borders = (1,77,1,13)
        self.borders = borders

