#!/usr/bin/env python

import sys
import curses


def create_win(subscr, attr):

    h,w,y,x = attr
    win=curses.newwin(h,w,y,x)
    win.idlok(1)
    win.scrollok(1)
    win.refresh()
    return(win)

def create_win_box(subscr, attr):

    h,w,y,x = attr
    win=curses.newwin(h,w,y,x)
    win.box()
    win.idlok(1)
    win.scrollok(1)
    win.refresh()
    return(win)


class Logscreen:

    def __init__(self, stdscr):


        attr = (8,79,16,0)
        h,w,y,x = attr


        self.bottom_line = h-3
        self.start_col = x+2

        self.bdr = stdscr.subwin(h,w,y,x)
        self.bdr.box()
        self.bdr.refresh()

        self.subscr = self.bdr.subwin(h-2,w-2,y+1,x+1)
        self.subscr.idlok(1)
        self.subscr.scrollok(1)
        self.subscr.refresh()

    def write_to(self, line):

        self.subscr.scroll(1)
        self.subscr.addstr(self.bottom_line, self.start_col, line)
        self.subscr.refresh()

