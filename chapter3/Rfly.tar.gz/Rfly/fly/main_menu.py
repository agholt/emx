#!/usr/bin/env python
 
import string, os
import re
import time
import sys, traceback
import exceptions
import termios
import curses
import commands

from constants import *
from common_functions import *

from logscreen import *
from service_screens import *
from options import *
#from network import *

from game import *



class Mainmenu(Options, Windows):

    def __init__(self, stdscr,logscr):

        self.stdscr = stdscr
        self.logscr = logscr

        self._set_params()


        h,w,y,x = (15,79,3,0)
        start_menu = ("Start Game", "self.start_func()")
        instructions_menu = ("Instructions", "self.instructions_func()")
        banner_menu = ("About", "self.banner_func()")
        quit_menu = ("Quit", "self.quit_func()")
        opts = (start_menu, instructions_menu, banner_menu, quit_menu)

        left,down = 34,4
        loops = 1
        while 1:
            self.debug_output("render main menu screen", 4)

            self.subscr = self.stdscr.subwin(h,w,y,x)

            if loops == 1:
                self.banner_func()
            loops += 1

            self.subscr.box()

            self.subscr.addstr(1, 34, "Main Menu", hotkey_attr)
            self.subscr.refresh()

            self.configure_opts(opts,down,left)
            self.subscr.refresh()

            self.debug_output("running key handler", 5)
            self.hot_keys()


    def hot_keys(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return eval(key_dict[c])


    def start_func(self):
        self.subscr.erase()
        S = Game(self.stdscr, self.logscr)


    def banner_func(self):
        self.subscr.erase()
        self._print_banner(self.stdscr)
        return 0

    def instructions_func(self):
        self.subscr.erase()
        self._print_instructions(self.stdscr)
        #self._print_banner(self.stdscr)
        return 0

    def quit_func(self):
        restore_terminal(self.stdscr)
        os._exit(0)


    def _set_params(self):

        # Set parameters 

        # Debug level 
        if env.has_key('DEBUG'):
            self.DEBUG = int(env['DEBUG'])
        else:
            self.DEBUG = 0

        dmsg = "debug level is %s" % (self.DEBUG)
        self.debug_output(dmsg, 0)
