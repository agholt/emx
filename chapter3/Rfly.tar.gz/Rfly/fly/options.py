#!/usr/bin/env python
 
import curses

from service_screens import *
from common_functions import *


                                                                                

class Options:
    def __init__(self):
        return 0
        
    def configure_options2(self, opts, left, down):
        for opt in opts:
            opt_name = opt[0]
            opt_hotkey = opt_name[0]
            opt_nohot = opt_name[1:]
            self.subscr.addstr(down, left, opt_hotkey, hotkey_attr)
            self.subscr.addstr(down, left+1, opt_nohot, menu_attr)
            #self.subscr.refresh()
            down = down + 1

            self.key_handler((string.upper(opt_hotkey), opt[1]))
            self.key_handler((string.lower(opt_hotkey), opt[1]))

    def configure_options(self, opts, down,left):
        for opt in opts:
            opt_name = opt[0]
            opt_hotkey = opt_name[0]
            opt_nohot = opt_name[1:]
            self.subscr.addstr(down, left, opt_hotkey, hotkey_attr)
            self.subscr.addstr(down, left+1, opt_nohot, menu_attr)
            down = down + 1

            self.key_handler((string.upper(opt_hotkey), opt[1]))
            self.key_handler((string.lower(opt_hotkey), opt[1]))

    def configure_opts(self, opts, down,left):
        for opt in opts:
            opt_name = opt[0]
            opt_hotkey = opt_name[0]
            opt_nohot = opt_name[1:]
            self.subscr.addstr(down, left, opt_hotkey, hotkey_attr)
            self.subscr.addstr(down, left+1, opt_nohot, menu_attr)
            down = down + 1

            self.hot_keys((string.upper(opt_hotkey), opt[1]))
            self.hot_keys((string.lower(opt_hotkey), opt[1]))

    def key_handler(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return eval(key_dict[c])

    def key_handler2(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return key_dict[c]

    def print_debug(self, output):
        dmsg = "%s: %s" % (get_time(), output)
        self.logscr.write_to(dmsg)

    def debug_output(self,output,priority):
        if int(env['DEBUG']) >= priority:
            dmsg = "%s: %s" % (get_time(), output)
            self.logscr.write_to(dmsg)
        return 0

    def _screen_hack(self):
        self.logscr.titlewin.addstr(1, 77, " ", curses.A_STANDOUT)
        self.logscr.titlewin.refresh()






