#!/usr/bin/env python

import string
import re
#import operator
import sys
import traceback
import curses

from constants import *
from common_functions import *


def create_win(subscr, attr):

    h,w,y,x = attr
    win=curses.newwin(h,w,y,x)
    win.idlok(1)
    win.scrollok(1)
    win.refresh()
    return(win)

def create_win_box(subscr, attr):

    h,w,y,x = attr
    win=curses.newwin(h,w,y,x)
    win.box()
    win.idlok(1)
    win.scrollok(1)
    win.refresh()
    return(win)


class ServScreens:

    def __init__(self, stdscr):

        self.stdscr = stdscr 
        self.title_window()
        self.log_window()

        #self.write_to_title(" Raspberry Fly ", 32, standout_attr) 

        dmsg = "%s: Starting Raspberry Fly...(%s)" % (get_time(), version)
        self.write_to(dmsg)
        dmsg = "%s: (c) Alan Holt 2012" % (get_time())
        self.write_to(dmsg)

    def title_window(self):
        h,w,y,x = (3,79,0,0)

        self.titlewin = self.stdscr.subwin(h,w,y,x)
        self.titlewin.box()
        left=2
        #title_str = " "*(32) + "Raspberry Fly" + " "*(32)
        title_bar = " "*(77)
        self.titlewin.addstr(1, left-1, title_bar, standout_attr)
        self.write_to_title(title_bar, 1, standout_attr) 
        self.write_to_title(" Raspberry Fly ", 32, standout_attr) 
        self.titlewin.refresh()


    def log_window(self):
        h,w,y,x = (6,79,18,0)

        self.bottom_line = h-3
        self.start_col = x+2

        bdr = self.stdscr.subwin(h,w,y,x)
        bdr.box()
        bdr.refresh()

        self.logwin = bdr.subwin(h-2,w-2,y+1,x+1)
        self.logwin.idlok(1)
        self.logwin.scrollok(1)
        self.logwin.refresh()

    def write_to(self, line):

        self.logwin.scroll(1)
        self.logwin.addstr(self.bottom_line, self.start_col, line)
        self.logwin.refresh()

    def write_to_title(self, line, x, attr):

        self.titlewin.addstr(1, x, line, attr)
        self.titlewin.refresh()




