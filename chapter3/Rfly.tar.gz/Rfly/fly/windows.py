#!/usr/bin/env python
 
import string, os
import re
import time
import sys, traceback
import termios
import curses

from service_screens import *
from constants import *
from common_functions import *
from options import *



class Windows:
    def __init__(self):
        return 0

    def _draw_screen(self,title, win_dimensions = WDIMS, attr=bold_uline_attr):

        self.h,self.w,self.y,self.x = win_dimensions

        self.center = int(self.w/2)
        title_len = len(title)
        title_pos = self.center - int(title_len/2) - 1 

        self.subscr = self.stdscr.subwin(self.h,self.w,self.y,self.x)
        self.subscr.box()
        self.subscr.addstr(1, title_pos, title, attr)

        self.subscr.refresh()


    def _draw_area(self, win_dimensions = WDIMS, attr=bold_uline_attr):

        self.h,self.w,self.y,self.x = win_dimensions

        self.subscr = self.stdscr.subwin(self.h,self.w,self.y,self.x)
        self.subscr.box()

        self.subscr.refresh()


    def _set_common_params(self):
        """ Set environment variables."""
        # Debug level
        if env.has_key('DEBUG'):
            self.DEBUG = int(env['DEBUG'])
        else:
            self.DEBUG = int(0)

        if env.has_key('LOGFILE'):
            self.logfile = env['LOGFILE']
        else:
            self.logfile = "/dev/null"


    def _any_key(self):
        msg =  "Hit any key to continue"

        down = self.h - 2
        msg_len = len(msg)
        left = self.center - int(msg_len/2) - 1 

        self.subscr.addstr(down, left, msg, norm_attr)
        self.subscr.refresh()
        c = self.subscr.getch()

    def _any_key_nonblock(self,tout):
        hit_key = 0
        msg =  "Hit any key to continue"

        down = self.h - 2
        msg_len = len(msg)
        left = self.center - int(msg_len/2) - 1 

        self.subscr.addstr(down, left, msg, norm_attr)
        self.subscr.refresh()
        self.subscr.timeout(tout)
        c = self.subscr.getch()
        self.subscr.timeout(-1)
        return c



    def _enter_text(self,prompt,current_val, response_len, wdims):

        down,left = 2,2
        offset = len(prompt)+2
        #wdims = (5,31,5,30)
        self._draw_screen(" ", wdims, bold_attr)
        self.subscr.addstr(down, left, prompt+": "+current_val, menu_attr)
        self.subscr.refresh()
 
        response = self.subscr.getstr(down,left+offset,response_len)

        self.subscr.addstr(2, left, " "*response_len, menu_attr)
        self.subscr.addstr(2, left, response, menu_attr)
        self.subscr.refresh()
        return response

    def _print_column(self,down,left,fields,attr):
        lower=0
        for field in fields:
            self.subscr.addstr(down+lower, left, field, attr)
            lower+=1

    def _print_banner(self,screen):

        h,w,y,x = (15,79,3,0)
        self.banscr = screen.subwin(h,w,y,x)
        self.banscr.box()

        down = 1
        for line in banner_text.split("\n"):
            self.banscr.addstr(down, 6, line, norm_attr)
            down += 1
        self.banscr.refresh()
        #self.banscr.addstr(down+4, 23,  "http://www.ip-performance.co.uk", norm_attr)


        for i in xrange(3):
            self.banscr.timeout(1)
            ct = time.ctime()
            day,mon,dat,tim,yr = ct.split()
            self.banscr.addstr(13, 68, tim, norm_attr)
            self.banscr.refresh()
            time.sleep(1)
            c = self.banscr.getch()
            if c != -1:
                break


        self.banscr.timeout(-1)
        self.banscr.erase()

    def _print_instructions(self,screen):
        h,w,y,x = (15,79,3,0)
        self.inscr = screen.subwin(h,w,y,x)

        self.inscr.box()
        self.inscr.addstr(1, 23, "Collect numbers to score points:", norm_attr)
        self.inscr.addstr(3, 27, "   Up arrow: move up", norm_attr)
        self.inscr.addstr(4, 27, " Down arrow: move down", norm_attr)
        self.inscr.addstr(5, 27, "Right arrow: move right", norm_attr)
        self.inscr.addstr(6, 27, " Left arrow: move left", norm_attr)
        self.inscr.addstr(12, 27, "Hit any key to continue", norm_attr)
        self.inscr.refresh()
        c = self.banscr.getch()
        self.banscr.timeout(-1)
        self.banscr.erase()

    def ping(self,dst):
        npackets = 5
        cmd = "ping -c %d %s 2>&1" % (npackets,dst)
        output, input = popen2(cmd)
        input.close()
        response = output.read()
        output.close()
        if re.search("unknown host", response):
            return -1
        nrec = 0
        for line in response.split('\n'):
            if re.search("packets transmitted", line):
                fields =  line.split(" ")
                nrec = fields[3]
                break
        dmsg = "PING: %s  %s packets sent, %s packets received " % \
                (dst,npackets, nrec)
        self.debug_output(dmsg, 2)
        return int(nrec)

    def _calc_index(self):

        try:
            for opt,i in zip(self.var_options,range(self.opt_len)):
                if self.var >= opt and self.var < self.var_options[i+1]:
                    self.opt_index = i
                    break
        except IndexError:
                self.opt_index = self.opt_len - 1


    def set_value(self,title,var,var_options):

        self.center = int(self.w/2)
        self.down, self.left = 3,2

        self.old_var = self.var = var
        self.debug_output("var: %d" % self.var,3)
        self.var_options = var_options
        self.min_opt = self.var_options[0]
        self.max_opt = self.var_options[-1]
        self.opt_len = len(self.var_options)
        self.opt_index = 1
        self._calc_index()


        self.offset = len(title)+2
        #self.offset = 20
        self.subscr.addstr(self.down, self.left, title+": ", norm_attr)
        self.subscr.addstr(self.down, self.left+self.offset, "%s" % self.var, norm_attr)

        prev_opt = ("A Up fast", "self.next_func()")
        next_opt = ("Z Down fast", "self.prev_func()")
        opts_pn = (prev_opt,next_opt)

        inc_opt = ("Increment", "self.inc_func()")
        dec_opt = ("Decrement", "self.dec_func()")
        opts_id = (inc_opt,dec_opt)

        save_opt = ("Save", "self.save_func()")
        opts_s = [save_opt]
        cancel_opt = ("Cancel", "self.cancel_func()")
        opts_c = [cancel_opt]

        while 1:
            self.configure_opts(opts_pn,self.down+2,self.center-12)
            self.configure_opts(opts_id,self.down+2,self.center+2)
            self.configure_opts(opts_s,self.down+5,self.center-6)
            self.configure_opts(opts_c,self.down+5,self.center+1)
            self.subscr.refresh()
            self.hot_keys()
            if self.end_of_screen:
                break

    def hot_keys2(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return eval(key_dict[c])



    def prev_func(self):
        self._calc_index()
        self.opt_index -= 1
        self.opt_index = self.opt_index % self.opt_len
        self.var = self.var_options[self.opt_index]
        self.subscr.addstr(self.down, self.left+self.offset, " "*5 , norm_attr)
        self.subscr.addstr(self.down, self.left+self.offset, "%s" % self.var, norm_attr)
        self.subscr.refresh()

    def next_func(self):
        self._calc_index()
        self.opt_index += 1
        self.opt_index = self.opt_index % self.opt_len
        self.var = self.var_options[self.opt_index]
        self.subscr.addstr(self.down, self.left+self.offset, " "*5 , norm_attr)
        self.subscr.addstr(self.down, self.left+self.offset, "%s" % self.var, norm_attr)
        self.subscr.refresh()

    def inc_func(self):
        self.var += 1
        self.var = self.var % self.max_opt
        if self.var == 0:
            self.var = self.max_opt
        self.var = min(self.var,self.max_opt)
        self.subscr.addstr(self.down, self.left+self.offset, " "*5 , norm_attr)
        self.subscr.addstr(self.down, self.left+self.offset, "%s" % self.var, norm_attr)
        self.subscr.refresh()

    def dec_func(self):
        self.var -= 1
        self.var = self.var % self.max_opt
        if self.var == 0:
            self.var = self.max_opt
        self.var = min(self.var,self.max_opt)
        self.subscr.addstr(self.down, self.left+self.offset, " "*5 , norm_attr)
        self.subscr.addstr(self.down, self.left+self.offset, "%s" % self.var, norm_attr)
        self.subscr.refresh()


    def save_func(self):
        #self._save_params()
        self.end_of_screen = 1

    def cancel_func(self):
        self.var = self.old_var
        self.end_of_screen = 1

    def quit_func(self):
        restore_terminal(self.stdscr)
        os._exit(0)

class ConfirmSelection(Options,Windows):
    def __init__(self, msg, stdscr,logscr):
        self.stdscr = stdscr
        self.logscr = logscr
        self.response = "N"

        yes_menu = ("Yes", "self.yes_option()")
        no_menu = ("No", "self.no_option()")
        opts = (yes_menu, no_menu)

        self._draw_screen(msg, (7,28,4,24), norm_attr)

        self.configure_opts(opts,3,11)
        self.subscr.refresh()
        self.hot_keys()
        self.subscr.erase()

    def hot_keys(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return eval(key_dict[c])


    def yes_option(self):
        self.response =  "Y"

    def no_option(self):
        self.response = "N"


class InvalidEntry(Options,Windows):
    def __init__(self, msg, stdscr,logscr):
        self.stdscr = stdscr
        self.logscr = logscr

        self.retry = 0
        self.back = 1
        yes_menu = ("Retry", "self.yes_option()")
        no_menu = ("Cancel", "self.no_option()")
        opts = (yes_menu, no_menu)

        self._draw_screen(msg, (7,28,5,24), bold_attr)

        self.configure_opts(opts,3,11)
        self.subscr.refresh()

        self.hot_keys()
        self.subscr.erase()

    def hot_keys(self, key_assign=None, key_dict={}):
        if key_assign:
            key_dict[ord(key_assign[0])] = key_assign[1]
        else:
            curses.noecho()
            c = self.subscr.getch()
            curses.echo()
            if c in (curses.KEY_END, ord('!')):
                return 0
            elif c not in key_dict.keys():
                curses.beep()
                return 1
            else:
                return eval(key_dict[c])


    def yes_option(self):
        return 0

    def no_option(self):
        self.subscr.erase()
        raise BackSignal, "go back to previous menu"

                                                                                
