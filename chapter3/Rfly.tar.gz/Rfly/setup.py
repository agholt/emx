from distutils.core import setup

setup(
      name             = 'fly',
      description      = 'Raspberry Fly',
      long_description = "Simple game for Raspberry Pi",
      author           = 'Alan Holt',
      author_email     = 'agholt@gmail.com',
      url              = 'http://www.raspberrypi.org/',
      version          = '0.2',
      license          = 'GPL',
      packages         = ['fly'],
      scripts         = ['rfly'],
)
